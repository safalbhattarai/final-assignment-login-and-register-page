package com.example.login_and_register_pages

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
